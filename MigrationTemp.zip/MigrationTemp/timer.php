<?php
date_default_timezone_set('Asia/Manila');
// Prints something like: Monday 8th of August 2005 03:12:46 PM
echo date('l\, jS \of F Y \| h:i:s A');

?>