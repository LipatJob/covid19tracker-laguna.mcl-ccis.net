# PROJECT COVID19
 Dashboard project for COVID19 : LAGUNA

Sir K.Kikuchi
Sir D.Martillano

Sir. J. Lipat

Disonglo, John 
Corpuz, John Noel 
Escarda, Gwyneth 

Flores Cedric
Gnilo, MJ
Hernandez, Mark Anthony
Lazaga, Joseph 
Cellona, Miguel 

